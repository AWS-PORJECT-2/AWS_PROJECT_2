# Tasks — 두띵 결제 시스템 + 디자인 업로드

> **Kiro에게**: 이 tasks 파일은 **순서대로** 진행해. 각 task는 이전 task가 끝나야 시작 가능해.
> 하나의 task가 끝날 때마다 빌드 + 린트 + (해당되면) 단위 테스트가 통과하는지 확인해.

---

## Phase 1 — 기반 (Day 1-3)

### Task 1.1 — DB 마이그레이션 작성
- `server/migrations/002_groupbuy_payment_design.sql` 파일 생성
- `design.md` 3.1 섹션의 SQL 그대로 사용
- 마이그레이션 적용 후 `\d` 명령으로 모든 테이블이 만들어졌는지 확인
- **완료 기준**: PostgreSQL에 8개 테이블(designs, groupbuys, groupbuy_options, participations, orders, payments, payment_events, refunds) + users 컬럼 추가 + 트리거 5개

### Task 1.2 — 타입 정의
다음 파일들을 `server/src/types/`에 생성:
- `design.ts` — Design 인터페이스
- `groupbuy.ts` — Groupbuy 인터페이스
- `groupbuy-option.ts` — GroupbuyOption 인터페이스
- `participation.ts` — Participation 인터페이스
- `order.ts` — Order 인터페이스
- `payment.ts` — Payment 인터페이스
- `payment-event.ts` — PaymentEvent 인터페이스
- `refund.ts` — Refund 인터페이스

각 인터페이스는 DB 컬럼과 1:1 매핑. snake_case는 camelCase로 변환.

**완료 기준**: 8개 파일 생성, TypeScript 빌드 성공

### Task 1.3 — Repository 인터페이스 + InMemory 구현
다음 6개 Repository를 `server/src/repositories/`에 생성:

각 Repository는 인터페이스 + InMemory 구현을 한 파일에 둔다 (기존 패턴):
- `design-repository.ts`
- `groupbuy-repository.ts` — `findByIdForUpdate`, `findRecruitingPastDeadline`, `incrementCount`, `updatePaidCount`, `calculateOptionDeltas` 메서드 포함
- `participation-repository.ts` — `findByIdForUpdate`, `findByGroupbuyAndUser`, `updateBillingKeyStatus` 포함
- `order-repository.ts` — `countByParticipation` 포함
- `payment-repository.ts`
- `payment-event-repository.ts` — append-only, update/delete 메서드 두지 않음

InMemory 구현은 트랜잭션 client 인자를 받지만 무시한다 (PG에서만 의미 있음).

**완료 기준**: 6개 파일, 각 Repository에 대한 단위 테스트 통과 (CRUD 기본 동작)

### Task 1.4 — PostgreSQL Repository 구현
6개 `pg-*-repository.ts` 파일을 `server/src/repositories/`에 생성:
- `pg-design-repository.ts`
- `pg-groupbuy-repository.ts` — `FOR UPDATE` 쿼리 사용
- `pg-participation-repository.ts` — `FOR UPDATE` 쿼리 사용
- `pg-order-repository.ts`
- `pg-payment-repository.ts`
- `pg-payment-event-repository.ts`

트랜잭션 client를 받아서 `client.query()` 호출하는 패턴. client가 `null`이면 pool에서 직접 쿼리.

**완료 기준**: 6개 파일, 통합 테스트 통과 (실제 PostgreSQL DB 사용)

---

## Phase 2 — 디자인 도메인 (Day 4-5)

### Task 2.1 — Storage 추상화
- `server/src/interfaces/storage-service.ts` 생성 (`design.md` 5.2 참고)
- `server/src/services/storage/local-storage-service.ts` — 로컬 파일시스템 + 테스트용 가짜 URL 반환
- `server/src/services/storage/s3-storage-service.ts` — AWS SDK v3 사용, pre-signed URL 발급

S3 구현은 `@aws-sdk/client-s3` + `@aws-sdk/s3-request-presigner` 라이브러리 필요. `package.json`에 추가.

`USE_LOCAL_STORAGE=true`면 LocalStorage 사용 (개발용).

**완료 기준**: 두 구현체 모두 `createPresignedUpload` 호출 시 정상 응답

### Task 2.2 — Design 서비스 + 라우트
- `server/src/interfaces/design-service.ts` (`design.md` 5.3)
- `server/src/services/design-service.ts` (`design.md` 7번 섹션 코드 사용)
- `server/src/routes/designs.ts` — 5개 핸들러 (create, declareCopyright, submit, listMine, getById)
- `server/src/routes/uploads.ts` — pre-signed URL 발급 엔드포인트

`app.ts`에 라우트 등록.

**완료 기준**: 다음 시나리오가 통과:
1. 사용자 A가 디자인 업로드 → DRAFT 상태
2. 사용자 A가 declareCopyright → copyrightSelfDeclared = true
3. 사용자 A가 submit → SUBMITTED 상태
4. 사용자 B가 사용자 A의 디자인 submit 시도 → 403
5. copyright 선언 없이 submit 시도 → 400

---

## Phase 3 — 결제 시스템 (Day 6-10)

### Task 3.1 — PG 추상화 + Mock 구현
- `server/src/interfaces/pg-client.ts` (`design.md` 5.1)
- `server/src/services/pg/null-pg-client.ts` — 항상 성공 반환하는 mock
- `server/src/utils/idempotency.ts` (`design.md` 6.1)

NullPgClient는 `charge` 호출 시 가짜 `pg_tx_id`를 반환하고, 성공/실패를 환경변수나 입력으로 시뮬레이션할 수 있게 한다.

**완료 기준**: NullPgClient의 단위 테스트 통과

### Task 3.2 — Payment 서비스 구현
- `server/src/interfaces/payment-service.ts` (`design.md` 5.4)
- `server/src/services/payment-service.ts` (`design.md` 6번 섹션 코드 그대로)

**중요**: 트랜잭션 분리 패턴 정확히 지킬 것.
- 1단계: BEGIN → order 생성 + 상태 변경 → COMMIT
- 2단계: 트랜잭션 밖에서 PG 호출
- 3단계: BEGIN → 결과 반영 → COMMIT

PG 호출을 BEGIN ~ COMMIT 사이에 두면 안 됨.

**완료 기준**: NullPgClient를 사용한 통합 테스트 통과 (다음 task에서 검증)

### Task 3.3 — Payment 서비스 단위 테스트
다음 12개 시나리오를 `server/src/services/payment-service.test.ts`에 작성:

1. **정상 흐름**: RESERVED → 마감 → 목표 달성 → PAID
2. **목표 미달**: RESERVED → 마감 → 미달성 → CANCELLED, 결제 0건
3. **결제 실패**: NullPgClient가 실패 반환 → CHARGE_FAILED
4. **동시 참여**: 동시에 마지막 자리 참여 → 한 명만 성공
5. **중복 참여**: 같은 사용자 두 번 참여 → 409
6. **금액 위조**: 클라이언트가 100원 보내도 서버가 unit_price × quantity로 계산
7. **마감 후 참여**: 마감 1초 후 참여 → 거부
8. **빌링키 비활성**: billing_key_status가 REVOKED → 결제 거부
9. **부분 결제 실패**: 100명 중 5명 실패 → SETTLED, 5명 CHARGE_FAILED
10. **재시도**: CHARGE_FAILED → CHARGE_RETRY → 결제 성공
11. **idempotency**: 같은 idempotency_key로 두 번 호출 → 한 번만 실행
12. **payment_events 기록**: 모든 결제 시도가 이벤트로 기록되는지

**완료 기준**: 12개 테스트 모두 통과

### Task 3.4 — PortOne 클라이언트 실구현
- `server/src/services/pg/portone-client.ts` (`design.md` 8번 섹션)
- `server/src/utils/fetch-with-timeout.ts`가 없으면 추가

포트원 v2 API 응답 포맷이 코드 예시와 다를 수 있음. 응답 받아서 매핑 시 사람한테 확인 받기.

**완료 기준**: 빌드 성공. 실제 호출 테스트는 환경변수 설정 후 별도로.

### Task 3.5 — webhook 핸들러
- `server/src/routes/webhooks/portone.ts` (`design.md` 9번 섹션)
- `app.ts`에 등록 시 `express.raw({ type: "application/json" })` 미들웨어 사용

**중요**: webhook 라우트만 raw body. 다른 라우트는 기존대로 JSON 파서 사용.

**완료 기준**:
- 정상 서명: 200 응답 + `payment_events`에 기록
- 잘못된 서명: 401 응답 + 기록은 됨 (signature_verified=false)
- 같은 webhook 두 번: 둘 다 기록되지만 비즈니스 처리는 멱등

### Task 3.6 — billing-key 라우트
- `server/src/routes/billing-key.ts` 또는 `server/src/routes/participations.ts`
- `POST /api/participations` 엔드포인트 — 빌링키 발급 후 호출

**완료 기준**:
- 인증된 사용자가 정상 데이터로 참여 → 201
- 마감 지난 공구 참여 → 400
- 중복 참여 → 409
- billingKeyRef 없이 요청 → 400

---

## Phase 4 — 자동화 (Day 11-12)

### Task 4.1 — Deadline scanner
- `server/src/jobs/deadline-scanner.ts` (`design.md` 10번 섹션)
- `server.ts`에서 부팅 시 `start(60_000)` 호출

테스트는 InMemory + NullPgClient 조합으로 가능.

**완료 기준**:
- 마감 지난 RECRUITING 공구가 1분 내 처리됨
- 처리 중 에러 발생 시 다음 스캔에서 재처리

### Task 4.2 — 결제 실패 재시도
- `server/src/jobs/retry-failed-charges.ts` 신규 작성
- 24시간마다 실행, CHARGE_FAILED 상태인 participation 찾아서 chargeParticipation 재호출
- attempt_no가 `CHARGE_RETRY_MAX_ATTEMPTS` 초과하면 EXCLUDED 처리

**완료 기준**:
- 첫 실패 → CHARGE_FAILED → 24h 후 재시도 → 성공 시 PAID
- 3회 실패 → EXCLUDED, 다음 재시도부터 제외

---

## Phase 5 — 통합 + 마무리 (Day 13-14)

### Task 5.1 — 의존성 주입 (DI) 와이어링
- `server/src/app.ts`에서 모든 서비스/Repository 생성 + 주입
- `USE_INMEMORY`, `USE_NULL_PG`, `USE_LOCAL_STORAGE` 환경변수 분기 처리
- `.env.example` 업데이트 (`design.md` 12번 섹션)

**완료 기준**:
- `USE_INMEMORY=true USE_NULL_PG=true USE_LOCAL_STORAGE=true` → DB/PG/S3 없이 부팅 성공
- 모든 환경변수 false → AWS RDS + 포트원 + S3 사용

### Task 5.2 — 전체 통합 테스트
end-to-end 시나리오를 작성:

1. 학생 A가 로그인 → 디자인 업로드 → 공구 개설
2. 학생 B, C, D가 공구 참여 → 빌링키 등록
3. 시간 빨리 감기 (테스트에서는 deadline을 1분 후로 설정)
4. 스캐너가 마감 감지 → 일괄 결제
5. 모든 학생 PAID 상태
6. payment_events에 모든 이벤트 기록 확인

목표 미달 시나리오도 동일하게 작성.

**완료 기준**: 두 시나리오 모두 통과

### Task 5.3 — 문서화
- `docs/payment-system.md` 생성: 결제 흐름 다이어그램, 상태 머신, 에러 코드 목록
- `docs/api.md` 업데이트: 새 엔드포인트 명세

---

## 작업 후 체크리스트

모든 task 완료 후 다음을 확인해줘:

- [ ] 12개 단위 테스트 + 2개 통합 테스트 모두 통과
- [ ] `npm run build` 에러 없음
- [ ] `npm run lint` 에러 없음
- [ ] `USE_INMEMORY=true USE_NULL_PG=true USE_LOCAL_STORAGE=true`로 로컬 부팅 성공
- [ ] 12번 절대 하지 말 것 (`design.md` 13번) 모두 지켜짐
- [ ] 새로 생성된 모든 파일이 두띵 코드 컨벤션을 따름 (kebab-case, 팩토리 패턴 등)

---

## 막히면 사람한테 물어볼 것

추측하지 말고 반드시 사람한테 확인:

1. 포트원 v2 API 응답 포맷이 `design.md` 8번 코드와 다를 때
2. 기존 `funds` 테이블이 이미 존재해서 마이그레이션 충돌
3. 사이즈/색상 옵션 구조에 `groupbuy_options` 테이블이 부족할 때
4. 결제 실패 재시도 정책 (3회로 충분한지, 카드 등록 다시 받을지)
5. 테스트 환경에서 빌링키 발급이 PG 정책으로 거부될 때
6. AWS S3 버킷 정책/CORS 설정이 필요할 때

이 6가지는 두띵 팀이 직접 결정해야 하는 부분이야.

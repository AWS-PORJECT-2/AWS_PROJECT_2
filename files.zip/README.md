# 두띵 백엔드 작업 — Kiro 지시서

> Kiro야 안녕. 이 폴더는 두띵(Doothing) 백엔드의 다음 작업 스펙이야.
> 작업 시작 전 아래 순서대로 읽어줘.

## 읽는 순서

1. **`requirements.md`** — 무엇을, 왜 만드는지 (먼저)
2. **`design.md`** — 어떻게 설계하는지 (그다음)
3. **`tasks.md`** — 무엇부터 할지 (마지막)

## 프로젝트 컨텍스트

두띵은 **국민대학교 학생 전용 의류 공동구매 플랫폼**이야. 이미 다음이 구축되어 있어:

- 백엔드: Node.js + Express + TypeScript (ESM, strict 모드)
- DB: PostgreSQL (AWS RDS)
- 인증: Google OAuth 2.0 + JWT (`@kookmin.ac.kr` 이메일만 허용)
- 패턴: Repository + DI + InMemory/PostgreSQL 분기 (`USE_INMEMORY` 환경변수)
- 프론트: Vanilla JS (별도 작업, 너는 백엔드만)

## 이번 작업 핵심

이번 작업에서 만들 두 가지:

1. **디자인 업로드 시스템** — 학생이 직접 만든 디자인(PNG/AI/PSD 등)을 업로드하고 공구의 기반으로 사용
2. **결제 시스템** — 텀블벅 스타일 빌링키 예약 결제 (목표 달성 시에만 결제 실행)

## 절대 만들지 말 것

이전 계획에서 빠졌어. 헷갈리지 마:

- ❌ AI 디자인 생성 기능 (ComfyUI 등) — 이번 작업에서 **제거**
- ❌ 일반 커머스 선결제 → 후환불 흐름 — 텀블벅 모델만 사용
- ❌ AI Try-on 연결 — 다음 단계, 지금은 인터페이스만 유지

## 기존 코드와의 관계

저장소의 기존 컨벤션을 따라줘:

- 새 엔티티 추가 시 3종 세트: `types/X.ts` + `repositories/X-repository.ts` + `repositories/pg-X-repository.ts`
- 라우트 핸들러는 팩토리 함수로 (`createXHandlers(deps)` 패턴)
- 파일명은 kebab-case
- 테스트는 핵심 비즈니스 로직(결제, 환불, 가격 계산)에 필수

## 막히면

다음 사항은 추측하지 말고 사람한테 물어봐줘:

- 포트원 v2 API 응답 포맷이 코드 예시와 다를 때
- 기존 `funds` 테이블이 있어서 마이그레이션 충돌
- 사이즈/색상 옵션 데이터 구조 변경 필요할 때
- 테스트 환경에서 빌링키 발급이 PG 정책으로 거부될 때

# Design — 두띵 결제 시스템 + 디자인 업로드

## 1. 아키텍처 개요

### 1.1 레이어 구조

기존 두띵 패턴(Repository + DI + InMemory/PG 분기)을 유지한다.

```
HTTP 요청
   │
   ▼
[routes/*]              ← Express 핸들러 (팩토리 패턴)
   │
   ▼
[services/*]            ← 비즈니스 로직 (트랜잭션 경계)
   │
   ▼
[repositories/*]        ← DB 접근 (InMemory + PG 두 구현)
   │                    [services/pg/portone-client.ts]  ← 외부 PG
   ▼                    [services/storage/s3-storage]    ← 외부 S3
PostgreSQL
```

### 1.2 외부 의존 추상화

PG와 S3는 인터페이스로 추상화해서 mock 테스트 가능하게 한다.

| 인터페이스 | 실구현 | Mock 구현 |
|---|---|---|
| `PgClient` | `PortOnePgClient` | `NullPgClient` |
| `StorageService` | `S3StorageService` | `LocalStorageService` |

---

## 2. 결제 라이프사이클

### 2.1 핵심 흐름

```
[참여 시점]
사용자 카드 입력 → PG가 빌링키 발급 → 두띵이 billing_key_ref 저장
→ participations.status = RESERVED (미결제)

[마감 시점] (deadline-scanner가 1분마다 감지)
groupbuy 마감 시간 도달
   │
   ├─ current_count >= target_count (목표 달성)
   │   → CHARGING 상태로 전환
   │   → 모든 RESERVED 참여자에게 빌링키로 일괄 결제
   │   → 성공: PAID, 실패: CHARGE_FAILED
   │   → SETTLED 상태로 전환
   │
   └─ current_count < target_count (목표 미달)
       → 모든 빌링키 폐기
       → participations.status = CANCELLED
       → 결제 실행 안 함
       → FAILED 상태로 전환
```

### 2.2 상태 머신

**`groupbuys.status`**
```
RECRUITING → DEADLINE_REACHED →
  ├─ SUCCESS → CHARGING → SETTLED → COMPLETED
  └─ FAILED
```

**`participations.status`**
```
RESERVED →
  ├─ CHARGE_PENDING → PAID → DELIVERED → COMPLETED
  ├─ CHARGE_FAILED → CHARGE_RETRY → (PAID | EXCLUDED)
  └─ CANCELLED
```

**`orders.status`**
```
DRAFT → CONFIRMED → CHARGE_PENDING →
  ├─ PAID → REFUND_REQUESTED → REFUNDED
  └─ CHARGE_FAILED
```

### 2.3 왜 `orders`와 `payments`를 분리하는가?

한 참여자에 대해 결제 시도가 여러 번 일어날 수 있다 (재시도). 시도마다 `orders`를 새로 만들고, 각 order에 대한 PG 호출 결과는 `payments`에 기록한다.

```
participation (1) ──< orders (N) ──< payments (N)
```

이렇게 하면 "어떤 시도가 언제 어떤 이유로 실패했는지" 추적 가능하다.

---

## 3. DB 스키마

### 3.1 마이그레이션 파일

`server/migrations/002_groupbuy_payment_design.sql`

```sql
-- ===== designs: 학생이 업로드한 디자인 자산 =====
CREATE TABLE designs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES users(id),
  title VARCHAR(200) NOT NULL,
  description TEXT,
  category VARCHAR(50) NOT NULL,
  preview_image_url VARCHAR(500) NOT NULL,
  source_file_url VARCHAR(500),
  source_file_format VARCHAR(20),
  target_dept VARCHAR(100),
  target_org VARCHAR(100),
  copyright_self_declared BOOLEAN NOT NULL DEFAULT FALSE,
  copyright_declared_at TIMESTAMPTZ,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (category IN ('OUTERWEAR', 'TOP', 'BOTTOM', 'ACCESSORY', 'GOODS', 'OTHER')),
  CHECK (status IN ('DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED', 'ARCHIVED')),
  CHECK (source_file_format IS NULL OR source_file_format IN ('PNG', 'JPG', 'AI', 'PSD', 'PDF', 'SVG'))
);
CREATE INDEX idx_designs_creator ON designs(creator_id);
CREATE INDEX idx_designs_status ON designs(status);
CREATE INDEX idx_designs_target_dept ON designs(target_dept);

-- ===== groupbuys: 공구 자체 =====
CREATE TABLE groupbuys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organizer_id UUID NOT NULL REFERENCES users(id),
  design_id UUID REFERENCES designs(id),
  title VARCHAR(200) NOT NULL,
  description TEXT,
  unit_price INTEGER NOT NULL CHECK (unit_price > 0),
  target_count INTEGER NOT NULL CHECK (target_count > 0),
  current_count INTEGER NOT NULL DEFAULT 0,
  paid_count INTEGER NOT NULL DEFAULT 0,
  target_dept VARCHAR(100),
  target_org VARCHAR(100),
  pickup_location VARCHAR(200),
  deadline TIMESTAMPTZ NOT NULL,
  estimated_delivery_at TIMESTAMPTZ,
  status VARCHAR(30) NOT NULL DEFAULT 'RECRUITING',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (status IN ('RECRUITING', 'DEADLINE_REACHED', 'SUCCESS', 'FAILED', 'CHARGING', 'SETTLED', 'COMPLETED'))
);
CREATE INDEX idx_groupbuys_status_deadline ON groupbuys(status, deadline);
CREATE INDEX idx_groupbuys_target_dept ON groupbuys(target_dept);
CREATE INDEX idx_groupbuys_organizer ON groupbuys(organizer_id);

-- ===== groupbuy_options: 사이즈/색상 옵션 =====
CREATE TABLE groupbuy_options (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  groupbuy_id UUID NOT NULL REFERENCES groupbuys(id) ON DELETE CASCADE,
  option_type VARCHAR(30) NOT NULL,
  option_value VARCHAR(100) NOT NULL,
  price_delta INTEGER NOT NULL DEFAULT 0,
  stock_limit INTEGER,
  display_order INTEGER NOT NULL DEFAULT 0,
  CHECK (option_type IN ('SIZE', 'COLOR', 'VARIANT'))
);
CREATE INDEX idx_groupbuy_options_groupbuy ON groupbuy_options(groupbuy_id);

-- ===== participations: 누가 어떤 공구에 참여했는지 =====
CREATE TABLE participations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  groupbuy_id UUID NOT NULL REFERENCES groupbuys(id),
  user_id UUID NOT NULL REFERENCES users(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  selected_options JSONB NOT NULL DEFAULT '[]'::jsonb,
  reserved_amount INTEGER NOT NULL CHECK (reserved_amount > 0),
  billing_key_ref VARCHAR(200),
  billing_key_status VARCHAR(20),
  status VARCHAR(30) NOT NULL DEFAULT 'RESERVED',
  reserved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(groupbuy_id, user_id),
  CHECK (status IN ('RESERVED', 'CHARGE_PENDING', 'PAID', 'CHARGE_FAILED', 'CHARGE_RETRY', 'EXCLUDED', 'CANCELLED', 'DELIVERED', 'COMPLETED')),
  CHECK (billing_key_status IS NULL OR billing_key_status IN ('ACTIVE', 'EXPIRED', 'REVOKED'))
);
CREATE INDEX idx_participations_groupbuy ON participations(groupbuy_id);
CREATE INDEX idx_participations_user ON participations(user_id);
CREATE INDEX idx_participations_status ON participations(status);

-- ===== orders: 결제 시도 단위 =====
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  participation_id UUID NOT NULL REFERENCES participations(id),
  total_amount INTEGER NOT NULL CHECK (total_amount > 0),
  idempotency_key VARCHAR(100) NOT NULL UNIQUE,
  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
  attempt_no INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (status IN ('DRAFT', 'CONFIRMED', 'CHARGE_PENDING', 'PAID', 'CHARGE_FAILED', 'REFUND_REQUESTED', 'REFUNDED'))
);
CREATE INDEX idx_orders_participation ON orders(participation_id);
CREATE INDEX idx_orders_status ON orders(status);

-- ===== payments: PG 거래 단위 =====
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id),
  pg_provider VARCHAR(30) NOT NULL DEFAULT 'portone',
  pg_tx_id VARCHAR(200),
  amount INTEGER NOT NULL,
  method VARCHAR(30),
  status VARCHAR(30) NOT NULL,
  failure_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE INDEX idx_payments_pg_tx ON payments(pg_tx_id);

-- ===== payment_events: PG raw 이벤트 (append-only, 절대 삭제 금지) =====
CREATE TABLE payment_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id UUID REFERENCES payments(id),
  participation_id UUID REFERENCES participations(id),
  event_type VARCHAR(50) NOT NULL,
  source VARCHAR(30) NOT NULL,
  raw_payload JSONB NOT NULL,
  signature_verified BOOLEAN NOT NULL DEFAULT FALSE,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_payment_events_payment ON payment_events(payment_id);
CREATE INDEX idx_payment_events_participation ON payment_events(participation_id);
CREATE INDEX idx_payment_events_type ON payment_events(event_type);

-- ===== refunds: 환불 시도 (예외 흐름) =====
CREATE TABLE refunds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id),
  amount INTEGER NOT NULL,
  reason TEXT NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
  pg_refund_id VARCHAR(200),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (status IN ('PENDING', 'APPROVED', 'COMPLETED', 'FAILED'))
);
CREATE INDEX idx_refunds_order ON refunds(order_id);

-- ===== users 테이블 확장 (캠퍼스 시그널) =====
ALTER TABLE users ADD COLUMN IF NOT EXISTS major VARCHAR(100);
ALTER TABLE users ADD COLUMN IF NOT EXISTS student_id VARCHAR(20);
ALTER TABLE users ADD COLUMN IF NOT EXISTS dept_verified BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS organizer_completed_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS organizer_avg_delivery_days INTEGER;

-- ===== updated_at 자동 갱신 트리거 =====
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_designs_updated_at BEFORE UPDATE ON designs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_groupbuys_updated_at BEFORE UPDATE ON groupbuys
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_participations_updated_at BEFORE UPDATE ON participations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_payments_updated_at BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

---

## 4. 파일 구조

```
server/src/
├── types/
│   ├── design.ts                       [NEW]
│   ├── groupbuy.ts                     [NEW]
│   ├── groupbuy-option.ts              [NEW]
│   ├── participation.ts                [NEW]
│   ├── order.ts                        [NEW]
│   ├── payment.ts                      [NEW]
│   ├── payment-event.ts                [NEW]
│   └── refund.ts                       [NEW]
├── interfaces/
│   ├── pg-client.ts                    [NEW]
│   ├── payment-service.ts              [NEW]
│   ├── design-service.ts               [NEW]
│   └── storage-service.ts              [NEW]
├── repositories/
│   ├── design-repository.ts            [NEW] InMemory + 인터페이스
│   ├── pg-design-repository.ts         [NEW] PostgreSQL
│   ├── groupbuy-repository.ts          [NEW]
│   ├── pg-groupbuy-repository.ts       [NEW]
│   ├── participation-repository.ts     [NEW]
│   ├── pg-participation-repository.ts  [NEW]
│   ├── order-repository.ts             [NEW]
│   ├── pg-order-repository.ts          [NEW]
│   ├── payment-repository.ts           [NEW]
│   ├── pg-payment-repository.ts        [NEW]
│   └── pg-payment-event-repository.ts  [NEW]
├── services/
│   ├── pg/
│   │   ├── portone-client.ts           [NEW]
│   │   └── null-pg-client.ts           [NEW]
│   ├── storage/
│   │   ├── s3-storage-service.ts       [NEW]
│   │   └── local-storage-service.ts    [NEW]
│   ├── design-service.ts               [NEW]
│   └── payment-service.ts              [NEW]
├── routes/
│   ├── designs.ts                      [NEW]
│   ├── groupbuys.ts                    [NEW]
│   ├── participations.ts               [NEW]
│   ├── uploads.ts                      [NEW] pre-signed URL
│   └── webhooks/
│       └── portone.ts                  [NEW]
├── jobs/
│   ├── deadline-scanner.ts             [NEW]
│   └── retry-failed-charges.ts         [NEW]
└── utils/
    └── idempotency.ts                  [NEW]
```

---

## 5. 인터페이스 정의

### 5.1 `interfaces/pg-client.ts`

```typescript
export interface IssueBillingKeyResult {
  billingKeyRef: string;
  cardName: string;
  cardLastFour: string;
  issuedAt: Date;
}

export interface ChargeParams {
  billingKeyRef: string;
  amount: number;
  orderName: string;
  idempotencyKey: string;
  customerId: string;
}

export interface ChargeResult {
  pgTxId: string;
  amount: number;
  method: string;
  approvedAt: Date;
}

export interface PgClient {
  charge(params: ChargeParams): Promise<ChargeResult>;
  cancelBillingKey(billingKeyRef: string): Promise<void>;
  refund(pgTxId: string, amount: number, reason: string): Promise<{ refundId: string }>;
  verifyWebhookSignature(rawBody: string, signature: string): boolean;
}
```

### 5.2 `interfaces/storage-service.ts`

```typescript
export interface PresignedUploadUrl {
  uploadUrl: string;
  publicUrl: string;
  fields?: Record<string, string>;
  expiresAt: Date;
}

export interface StorageService {
  createPresignedUpload(params: {
    userId: string;
    contentType: string;
    purpose: 'design_preview' | 'design_source' | 'profile' | 'review';
    maxSizeBytes: number;
  }): Promise<PresignedUploadUrl>;

  generatePresignedDownload(key: string, expiresInSeconds: number): Promise<string>;
  deleteObject(key: string): Promise<void>;
}
```

### 5.3 `interfaces/design-service.ts`

```typescript
import type { Design } from "../types/design.js";

export interface DesignService {
  createDraft(input: {
    creatorId: string;
    title: string;
    category: string;
    previewImageUrl: string;
    sourceFileUrl?: string;
    sourceFileFormat?: string;
    description?: string;
    targetDept?: string;
    targetOrg?: string;
  }): Promise<Design>;

  declareCopyright(designId: string, userId: string): Promise<Design>;
  submit(designId: string, userId: string): Promise<Design>;
  archive(designId: string, userId: string): Promise<void>;
  findByCreator(userId: string): Promise<Design[]>;
  findById(designId: string): Promise<Design | null>;
}
```

### 5.4 `interfaces/payment-service.ts`

```typescript
import type { Participation } from "../types/participation.js";

export interface PaymentService {
  reserveParticipation(input: {
    groupbuyId: string;
    userId: string;
    quantity: number;
    selectedOptions?: Array<{ optionType: string; optionValue: string }>;
    billingKeyRef: string;
  }): Promise<Participation>;

  chargeGroupbuy(groupbuyId: string): Promise<{
    paid: number;
    failed: number;
    excluded: number;
  }>;

  chargeParticipation(participationId: string): Promise<void>;
  revokeAllBillingKeys(groupbuyId: string): Promise<void>;
}
```

---

## 6. 핵심 비즈니스 로직 — `services/payment-service.ts`

가장 중요한 파일이다. 트랜잭션 처리와 PG 호출 분리를 정확히 지킬 것.

```typescript
import type { PaymentService } from "../interfaces/payment-service.js";
import type { PgClient } from "../interfaces/pg-client.js";
import type { GroupbuyRepository } from "../repositories/groupbuy-repository.js";
import type { ParticipationRepository } from "../repositories/participation-repository.js";
import type { OrderRepository } from "../repositories/order-repository.js";
import type { PaymentRepository } from "../repositories/payment-repository.js";
import type { PaymentEventRepository } from "../repositories/payment-event-repository.js";
import { generateIdempotencyKey } from "../utils/idempotency.js";
import { AppError } from "../errors/app-error.js";
import { logger } from "../logger.js";
import type { Pool } from "pg";

export function createPaymentService(deps: {
  pool: Pool;
  pgClient: PgClient;
  groupbuyRepo: GroupbuyRepository;
  participationRepo: ParticipationRepository;
  orderRepo: OrderRepository;
  paymentRepo: PaymentRepository;
  eventRepo: PaymentEventRepository;
}): PaymentService {
  const { pool, pgClient, groupbuyRepo, participationRepo, orderRepo, paymentRepo, eventRepo } = deps;

  async function reserveParticipation(input) {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      // 1. 공구 잠금 (FOR UPDATE) — 동시 참여 방지
      const groupbuy = await groupbuyRepo.findByIdForUpdate(client, input.groupbuyId);
      if (!groupbuy) throw new AppError("GROUPBUY_NOT_FOUND", 404);
      if (groupbuy.status !== "RECRUITING") throw new AppError("GROUPBUY_NOT_RECRUITING", 400);
      if (new Date() > groupbuy.deadline) throw new AppError("GROUPBUY_EXPIRED", 400);

      // 2. 중복 참여 체크
      const existing = await participationRepo.findByGroupbuyAndUser(
        client, input.groupbuyId, input.userId
      );
      if (existing) throw new AppError("ALREADY_PARTICIPATED", 409);

      // 3. 가격 계산 — 서버에서 무조건 다시 계산
      const optionDeltas = await groupbuyRepo.calculateOptionDeltas(
        client, input.groupbuyId, input.selectedOptions ?? []
      );
      const reservedAmount = (groupbuy.unitPrice + optionDeltas) * input.quantity;
      if (reservedAmount <= 0) throw new AppError("INVALID_AMOUNT", 400);

      // 4. participation 생성
      const participation = await participationRepo.create(client, {
        groupbuyId: input.groupbuyId,
        userId: input.userId,
        quantity: input.quantity,
        selectedOptions: input.selectedOptions ?? [],
        reservedAmount,
        billingKeyRef: input.billingKeyRef,
        billingKeyStatus: "ACTIVE",
        status: "RESERVED",
      });

      // 5. 카운트 증가
      await groupbuyRepo.incrementCount(client, input.groupbuyId);

      // 6. 이벤트 로그
      await eventRepo.create(client, {
        participationId: participation.id,
        eventType: "BILLING_KEY_REGISTERED",
        source: "internal",
        rawPayload: { billingKeyRef: input.billingKeyRef, reservedAmount },
        signatureVerified: true,
      });

      await client.query("COMMIT");
      return participation;
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  }

  async function chargeGroupbuy(groupbuyId: string) {
    const groupbuy = await groupbuyRepo.findById(groupbuyId);
    if (!groupbuy) throw new AppError("GROUPBUY_NOT_FOUND", 404);
    if (groupbuy.status !== "DEADLINE_REACHED") {
      throw new AppError("INVALID_STATUS", 400);
    }

    // 목표 미달 — 빌링키 폐기
    if (groupbuy.currentCount < groupbuy.targetCount) {
      await revokeAllBillingKeys(groupbuyId);
      await groupbuyRepo.updateStatus(groupbuyId, "FAILED");
      logger.info({ groupbuyId }, "Groupbuy failed, billing keys revoked");
      return { paid: 0, failed: 0, excluded: 0 };
    }

    // 목표 달성 — 일괄 결제
    await groupbuyRepo.updateStatus(groupbuyId, "CHARGING");

    const participations = await participationRepo.findByGroupbuy(groupbuyId, {
      status: "RESERVED",
    });

    let paid = 0, failed = 0, excluded = 0;

    for (const p of participations) {
      try {
        await chargeParticipation(p.id);
        paid++;
      } catch (err) {
        logger.error({ err, participationId: p.id }, "Charge failed");
        failed++;
      }
    }

    await groupbuyRepo.updatePaidCount(groupbuyId, paid);
    await groupbuyRepo.updateStatus(groupbuyId, "SETTLED");

    return { paid, failed, excluded };
  }

  async function chargeParticipation(participationId: string) {
    // ★ 핵심: 트랜잭션을 두 번 분리한다.
    //   1단계: 트랜잭션 안에서 order 생성 + 상태 변경 → COMMIT
    //   2단계: 트랜잭션 밖에서 PG 호출 (외부 I/O)
    //   3단계: 트랜잭션 안에서 결과 반영
    // PG 호출을 트랜잭션 안에 두면 락이 오래 걸려서 데드락 위험.

    let order;
    let p;

    // 1단계
    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      const found = await participationRepo.findByIdForUpdate(client, participationId);
      if (!found) throw new AppError("PARTICIPATION_NOT_FOUND", 404);
      if (found.status !== "RESERVED" && found.status !== "CHARGE_RETRY") {
        throw new AppError("INVALID_PARTICIPATION_STATUS", 400);
      }
      if (!found.billingKeyRef || found.billingKeyStatus !== "ACTIVE") {
        throw new AppError("BILLING_KEY_NOT_ACTIVE", 400);
      }
      p = found;

      const previousAttempts = await orderRepo.countByParticipation(client, participationId);
      const attemptNo = previousAttempts + 1;
      const idempotencyKey = generateIdempotencyKey(participationId, attemptNo);

      order = await orderRepo.create(client, {
        participationId: p.id,
        totalAmount: p.reservedAmount,
        idempotencyKey,
        status: "CHARGE_PENDING",
        attemptNo,
      });

      await participationRepo.updateStatus(client, p.id, "CHARGE_PENDING");

      await client.query("COMMIT");
    } catch (err) {
      try { await client.query("ROLLBACK"); } catch {}
      client.release();
      throw err;
    }
    client.release();

    // 2단계: 트랜잭션 밖에서 PG 호출
    let chargeResult;
    try {
      chargeResult = await pgClient.charge({
        billingKeyRef: p.billingKeyRef,
        amount: p.reservedAmount,
        orderName: `두띵 공구 #${p.groupbuyId.slice(0, 8)}`,
        idempotencyKey: order.idempotencyKey,
        customerId: p.userId,
      });
    } catch (pgErr) {
      await markChargeFailed(p.id, order.id, pgErr);
      throw pgErr;
    }

    // 3단계: 결과 반영
    await markChargeSucceeded(p.id, order.id, chargeResult);
  }

  async function markChargeSucceeded(participationId, orderId, result) {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      const payment = await paymentRepo.create(client, {
        orderId,
        pgProvider: "portone",
        pgTxId: result.pgTxId,
        amount: result.amount,
        method: result.method,
        status: "PAID",
      });

      await orderRepo.updateStatus(client, orderId, "PAID");
      await participationRepo.updateStatus(client, participationId, "PAID");

      await eventRepo.create(client, {
        paymentId: payment.id,
        participationId,
        eventType: "CHARGE_SUCCEEDED",
        source: "pg_response",
        rawPayload: result,
        signatureVerified: true,
      });

      await client.query("COMMIT");
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  }

  async function markChargeFailed(participationId, orderId, err) {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      await orderRepo.updateStatus(client, orderId, "CHARGE_FAILED");
      await participationRepo.updateStatus(client, participationId, "CHARGE_FAILED");

      await eventRepo.create(client, {
        participationId,
        eventType: "CHARGE_FAILED",
        source: "internal",
        rawPayload: { error: String(err) },
        signatureVerified: true,
      });

      await client.query("COMMIT");
    } catch (logErr) {
      await client.query("ROLLBACK");
      logger.error({ logErr }, "Failed to log charge failure");
    } finally {
      client.release();
    }
  }

  async function revokeAllBillingKeys(groupbuyId: string) {
    const participations = await participationRepo.findByGroupbuy(groupbuyId, {
      status: "RESERVED",
    });

    for (const p of participations) {
      if (!p.billingKeyRef) continue;
      try {
        await pgClient.cancelBillingKey(p.billingKeyRef);
        await participationRepo.updateBillingKeyStatus(p.id, "REVOKED");
        await participationRepo.updateStatus(null, p.id, "CANCELLED");
      } catch (err) {
        logger.error({ err, participationId: p.id }, "Failed to revoke billing key");
      }
    }
  }

  return { reserveParticipation, chargeGroupbuy, chargeParticipation, revokeAllBillingKeys };
}
```

### 6.1 `utils/idempotency.ts`

```typescript
import { createHash } from "node:crypto";

export function generateIdempotencyKey(participationId: string, attemptNo: number): string {
  const raw = `${participationId}:${attemptNo}:v1`;
  return createHash("sha256").update(raw).digest("hex").slice(0, 64);
}
```

---

## 7. 디자인 서비스 — `services/design-service.ts`

```typescript
import type { DesignService } from "../interfaces/design-service.js";
import type { DesignRepository } from "../repositories/design-repository.js";
import { AppError } from "../errors/app-error.js";

const VALID_CATEGORIES = ['OUTERWEAR', 'TOP', 'BOTTOM', 'ACCESSORY', 'GOODS', 'OTHER'];

export function createDesignService(deps: {
  designRepo: DesignRepository;
}): DesignService {
  const { designRepo } = deps;

  async function createDraft(input) {
    if (!input.title || input.title.length > 200) {
      throw new AppError("INVALID_TITLE", 400);
    }
    if (!VALID_CATEGORIES.includes(input.category)) {
      throw new AppError("INVALID_CATEGORY", 400);
    }
    return designRepo.create({
      ...input,
      status: 'DRAFT',
      copyrightSelfDeclared: false,
    });
  }

  async function declareCopyright(designId: string, userId: string) {
    const design = await designRepo.findById(designId);
    if (!design) throw new AppError("DESIGN_NOT_FOUND", 404);
    if (design.creatorId !== userId) throw new AppError("FORBIDDEN", 403);
    return designRepo.update(designId, {
      copyrightSelfDeclared: true,
      copyrightDeclaredAt: new Date(),
    });
  }

  async function submit(designId: string, userId: string) {
    const design = await designRepo.findById(designId);
    if (!design) throw new AppError("DESIGN_NOT_FOUND", 404);
    if (design.creatorId !== userId) throw new AppError("FORBIDDEN", 403);
    if (!design.copyrightSelfDeclared) {
      throw new AppError("COPYRIGHT_DECLARATION_REQUIRED", 400);
    }
    if (design.status !== 'DRAFT') {
      throw new AppError("INVALID_STATUS", 400);
    }
    return designRepo.update(designId, { status: 'SUBMITTED' });
  }

  async function archive(designId: string, userId: string) {
    const design = await designRepo.findById(designId);
    if (!design) throw new AppError("DESIGN_NOT_FOUND", 404);
    if (design.creatorId !== userId) throw new AppError("FORBIDDEN", 403);
    await designRepo.update(designId, { status: 'ARCHIVED' });
  }

  return {
    createDraft, declareCopyright, submit, archive,
    findByCreator: (userId) => designRepo.findByCreator(userId),
    findById: (designId) => designRepo.findById(designId),
  };
}
```

---

## 8. 포트원 클라이언트 — `services/pg/portone-client.ts`

```typescript
import type { PgClient, ChargeParams, ChargeResult } from "../../interfaces/pg-client.js";
import { fetchWithTimeout } from "../../utils/fetch-with-timeout.js";
import { createHmac, timingSafeEqual } from "node:crypto";
import { AppError } from "../../errors/app-error.js";

export function createPortOneClient(config: {
  storeId: string;
  apiSecret: string;
  channelKey: string;
  webhookSecret: string;
  apiBaseUrl?: string;
  timeoutMs?: number;
}): PgClient {
  const baseUrl = config.apiBaseUrl ?? "https://api.portone.io";
  const timeout = config.timeoutMs ?? 10_000;

  async function request<T>(path: string, method: 'POST' | 'GET', body?: unknown): Promise<T> {
    const res = await fetchWithTimeout(`${baseUrl}${path}`, {
      method,
      headers: {
        "Authorization": `PortOne ${config.apiSecret}`,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
      timeoutMs: timeout,
    });
    if (!res.ok) {
      const text = await res.text();
      throw new AppError(`PG_ERROR: ${res.status} ${text}`, 502);
    }
    return res.json() as Promise<T>;
  }

  return {
    async charge(params: ChargeParams): Promise<ChargeResult> {
      const result = await request<{
        payment: {
          id: string;
          amount: { total: number };
          method: { type: string };
          paidAt: string;
        };
      }>(`/payments/${params.idempotencyKey}/billing-key`, 'POST', {
        billingKey: params.billingKeyRef,
        orderName: params.orderName,
        amount: { total: params.amount, currency: "KRW" },
        customer: { id: params.customerId },
      });
      return {
        pgTxId: result.payment.id,
        amount: result.payment.amount.total,
        method: result.payment.method.type,
        approvedAt: new Date(result.payment.paidAt),
      };
    },

    async cancelBillingKey(billingKeyRef: string): Promise<void> {
      await request(`/billing-keys/${billingKeyRef}/cancel`, 'POST', {});
    },

    async refund(pgTxId, amount, reason) {
      const result = await request<{ cancellation: { id: string } }>(
        `/payments/${pgTxId}/cancel`, 'POST', { amount, reason }
      );
      return { refundId: result.cancellation.id };
    },

    verifyWebhookSignature(rawBody, signature) {
      const expected = createHmac("sha256", config.webhookSecret)
        .update(rawBody).digest("hex");
      const sigBuf = Buffer.from(signature, "hex");
      const expBuf = Buffer.from(expected, "hex");
      if (sigBuf.length !== expBuf.length) return false;
      return timingSafeEqual(sigBuf, expBuf);
    },
  };
}
```

> **Kiro 주의**: 포트원 v2 API 경로는 예시야. 실제 구현 시 https://developers.portone.io/api/rest-v2 에서 최신 엔드포인트 확인하고, 응답 포맷이 다르면 사람한테 물어봐.

---

## 9. webhook 핸들러 — `routes/webhooks/portone.ts`

```typescript
import type { Request, Response } from "express";
import type { PgClient } from "../../interfaces/pg-client.js";
import type { PaymentEventRepository } from "../../repositories/payment-event-repository.js";
import { logger } from "../../logger.js";

export function createPortOneWebhookHandler(deps: {
  pgClient: PgClient;
  eventRepo: PaymentEventRepository;
}) {
  return async function handleWebhook(req: Request, res: Response) {
    const signature = req.header("x-portone-signature") ?? "";
    const rawBody = (req.body as Buffer).toString("utf-8");

    const verified = deps.pgClient.verifyWebhookSignature(rawBody, signature);
    if (!verified) {
      logger.warn({ ip: req.ip }, "Invalid webhook signature");
      try {
        await deps.eventRepo.create(null, {
          eventType: "WEBHOOK_INVALID_SIGNATURE",
          source: "portone_webhook",
          rawPayload: { rawBody, signature, ip: req.ip },
          signatureVerified: false,
        });
      } catch {}
      return res.status(401).json({ error: "Invalid signature" });
    }

    const payload = JSON.parse(rawBody);

    await deps.eventRepo.create(null, {
      eventType: `WEBHOOK_${payload.type}`,
      source: "portone_webhook",
      rawPayload: payload,
      signatureVerified: true,
    });

    res.status(200).json({ received: true });

    setImmediate(async () => {
      try {
        await processWebhookEvent(payload, deps);
      } catch (err) {
        logger.error({ err, payload }, "Webhook processing failed");
      }
    });
  };
}

async function processWebhookEvent(payload, deps) {
  // Transaction.Paid, Transaction.Failed, BillingKey.Issued, BillingKey.Deleted 등 분기
}
```

**`app.ts` 라우트 등록 시 주의**:

```typescript
// webhook은 raw body 미들웨어 사용 (서명 검증 위해)
app.post(
  "/api/webhooks/portone",
  express.raw({ type: "application/json" }),
  webhookHandler
);
```

---

## 10. 스케줄러 — `jobs/deadline-scanner.ts`

```typescript
import type { GroupbuyRepository } from "../repositories/groupbuy-repository.js";
import type { PaymentService } from "../interfaces/payment-service.js";
import { logger } from "../logger.js";

export function createDeadlineScanner(deps: {
  groupbuyRepo: GroupbuyRepository;
  paymentService: PaymentService;
}) {
  async function scan() {
    const now = new Date();
    const expired = await deps.groupbuyRepo.findRecruitingPastDeadline(now);

    for (const gb of expired) {
      try {
        await deps.groupbuyRepo.updateStatus(gb.id, "DEADLINE_REACHED");
        const result = await deps.paymentService.chargeGroupbuy(gb.id);
        logger.info({ groupbuyId: gb.id, ...result }, "Groupbuy processed");
      } catch (err) {
        logger.error({ err, groupbuyId: gb.id }, "Failed to process groupbuy");
        await deps.groupbuyRepo.updateStatus(gb.id, "RECRUITING").catch(() => {});
      }
    }
  }

  function start(intervalMs = 60_000) {
    setInterval(() => {
      scan().catch((err) => logger.error({ err }, "Scanner crashed"));
    }, intervalMs);
    logger.info("Deadline scanner started");
  }

  return { scan, start };
}
```

`server.ts`에서 부팅 시 `deadlineScanner.start(60_000)` 호출.

---

## 11. API 엔드포인트

| 메서드 | 경로 | 인증 | 설명 |
|---|---|---|---|
| POST | /api/uploads/presigned | ✓ | S3 업로드용 pre-signed URL 발급 |
| POST | /api/designs | ✓ | 디자인 초안 생성 |
| POST | /api/designs/:id/declare-copyright | ✓ | 저작권 자기 선언 |
| POST | /api/designs/:id/submit | ✓ | 디자인 제출 |
| GET | /api/designs/me | ✓ | 내 디자인 목록 |
| GET | /api/designs/:id | X | 디자인 상세 |
| GET | /api/groupbuys | X | 공구 목록 (학과 필터 지원) |
| GET | /api/groupbuys/:id | X | 공구 상세 |
| POST | /api/groupbuys | ✓ | 공구 개설 |
| POST | /api/participations | ✓ | 공구 참여 (빌링키 등록 후) |
| GET | /api/participations/me | ✓ | 내 참여 내역 |
| POST | /api/webhooks/portone | X | 포트원 webhook (서명 검증) |

---

## 12. 환경 변수

`.env.example` 추가:

```bash
# 포트원
PORTONE_STORE_ID=
PORTONE_API_SECRET=
PORTONE_CHANNEL_KEY=
PORTONE_WEBHOOK_SECRET=
PORTONE_API_BASE_URL=https://api.portone.io

# AWS S3 (디자인 자산)
AWS_REGION=ap-northeast-2
AWS_S3_BUCKET=doothing-assets
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=

# 결제 정책
CHARGE_RETRY_MAX_ATTEMPTS=3
CHARGE_RETRY_INTERVAL_HOURS=24
DEADLINE_SCAN_INTERVAL_MS=60000

# 테스트 모드
USE_NULL_PG=false
USE_LOCAL_STORAGE=false
```

---

## 13. 절대 하지 말 것

- ❌ 빌링키 자체를 두띵 DB에 저장 (PG의 `billing_key_ref` ID만 저장)
- ❌ 카드 번호, CVC, 비밀번호를 어디든 로깅
- ❌ 클라이언트가 보낸 금액을 결제 금액으로 사용
- ❌ webhook에서 서명 검증 생략
- ❌ `payment_events` 테이블의 데이터 삭제
- ❌ idempotency key 없이 결제 호출
- ❌ PG 호출을 DB 트랜잭션 안에서 (외부 I/O가 트랜잭션 잡고 있으면 락 오래 걸림)
- ❌ 결제 실패 후 자동으로 무한 재시도
- ❌ 디자인 원본 파일을 public S3에 업로드 (private 버킷 + signed URL만)
- ❌ AI 디자인 생성 라우트를 다시 추가 (스코프 아웃)
